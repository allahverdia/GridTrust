# -*- coding: utf-8 -*-
"""
Created on Sun Sep  5 13:12:34 2021

@author: K
"""
import serial
import time
#import requests
from datetime import datetime


def write_to_log(body):
    with open('C:/Users/K/Desktop/RanCodetemplog.txt', 'a') as file:
        s = "Year %s Month %s Day %s %s:%s:%s\n" % ((body["year"]),
        (body["month"]), (body["day"]), (body["hour"]), (body["minute"]), (body["second"]))
        file.write(s)
        file.write("Temperature " + body["temperature"] + "F\n")
        file.close()

def message_test(body):
    print(body["temperature"])
    #print(body["year"])
    #print(body["month"])
    #print(body["day"])
    print(body["hour"])
    print(body["minute"])
    print(body["second"])

'''def post_request(server_name, action, body, node_certificate, node_key):
   	request_url= 'https://{}/{}'.format(server_name,action)
	request_headers = {
		'Content-Type': "application/json"
		}
	response = requests.post(
		url= request_url,
		data=json.dumps(body),
		headers = request_headers,
		cert = (node_certificate, node_key),
	)
	return response
'''

def serial_read():
    time.sleep(0.05)
    data = serialport.readline().decode('utf-8').rstrip()
    return data


openport = 'COM7'
print(datetime.now())
serial.Serial(port=openport).close()
serialport = serial.Serial(port=openport, baudrate=9600, timeout=.1)



#print(file.readline())
position = 0
temperature = 0
while True:
    line = serial_read()
    index = line.find("Temp")
    if index != -1 :
        # print(line[13 : 18])
        temperature = line[13 : 18]
    if temperature != 0:
        #print(temperature)
        # print(voltage)
        now = datetime.now()
        body = {
            "temperature": temperature,
            "year": now.year,
            "month": now.month,
            "day": now.day,
            "hour": now.hour,
            "minute": now.minute,
            "second": now.second,
                    
        }
        temperature = 0
        message_test(body)
        write_to_log(body)