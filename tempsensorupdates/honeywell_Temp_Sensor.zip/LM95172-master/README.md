LM95172
=======

Arduino library for LM95172 temperature sensor. For more information, please see <a href="http://www.kerrywong.com/2013/02/21/arduino-library-for-lm95172-temperature-sensor/">Arduino Library For LM95172 Temperature Sensor</a>.
