#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
//#include "LM95172.h"

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

#define USER_IO_DIR     (0x01000000)
#define BIT_LED         (0x01000000)

//MASK for IO direction. '1' indictates output,'0' input
#define USER_IO_DIR_GPIO1_Input (0x00400000) //This is for when PIN_SIO is used as input
#define USER_IO_DIR_GPIO1_Output (0x00400800) //This is for when PIN_SIO is used as output
#define USER_IO_DIR_GPIO2		 (0x00000180)

#define PIN_CS  (0x00400000)//Output, HPS_GPIO51
#define PIN_SC  (0x00000100)//Output, HPS_GPIO66
#define PIN_SIO (0x00000800)//IO, HPS_GPIO40
#define PIN_OT  (0x00000080)//Input, HPS_GPIO65






//Require 4 pins. Easiest to use are HPS_LTC_GPIO, HPS_GPIO40, pin 14 on LTC header
//HPS_SPIM_MISO, HPS_GPIO65, pin 5 on LTC header
//HPS_SPIM_SS, HPS_GPIO66, pin 6 on LTC header
//HPS_I2C2_SDAT, HPS_GPIO51, pin 9 on LTC header


int main(int argc, char **argv) {


  static const int READ = 1;
  static const int WRITE = 0;
  static const int CELSIUS = 1;
  static const int FAHRENHEIT = 0;

  static const byte REG_CTL = 0x1;
  static const byte REG_TH = 0x2;
  static const byte REG_TL = 0x3;
  static const byte REG_ID = 0x7;

  static const byte CTRL_SHUT_DOWN = 15;
  static const byte CTRL_ONE_SHOT = 14;
  static const byte CTRL_OVERTEMP_RST = 13;
  static const byte CTRL_CONV_TOGGLE = 12;
  static const byte CTRL_OVERTEMP_STAT = 11;
  static const byte CTRL_T_HIGH = 10;
  static const byte CTRL_T_LOW = 9;
  static const byte CTRL_DATA_AVAIL = 8;
  static const byte CTRL_OVERTEMP_DIS = 7;
  static const byte CTRL_OVERTEMP_POL = 6;
  static const byte CTRL_RES_1 = 5;
  static const byte CTRL_RES_0 = 4;






	const void *virtual_base;
	int fd;
	uint32_t  scan_input;
	int i;		
	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}

	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return( 1 );
	}
	
	init(virtual_base);
	resetSensor();
	
	
	
	

	// clean up our memory mapping and exit
	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );
	}	
	close( fd );
	return( 0 );
}


void init(void *virtual_base) {
	alt_setbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO1_SWPORTA_DDR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), USER_IO_DIR_GPIO1_Input );
	alt_setbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO2_SWPORTA_DDR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), USER_IO_DIR_GPIO2 );
	
	writeCS(1);
	writeSC(0);
	writeSIO(1);
	
	//resetSensor();
}


void resetSensor(){
	
	unsigned int v = 0;
	
	writeCS(0);
	readTemp();
	writeCMD(READ, REG_CTL, v);
	writeCS(1);
	v = v | (1 << CTRL_SHUT_DOWN); //shutdown bit;
	writeCS(0);
	readTemp();
	writeCMD(WRITE, REG_CTL, v);
	//wait
	writeCS(1);
	
	v = v | (0 << CTRL_SHUT_DOWN); //clear shutdown bit;
	writeCS(0);
	readTemp();
	writeCMD(WRITE, REG_CTL, v);
	//wait
	writeCS(1);
	
	
}

void writeCS(int i){
	if (i == 1){
		alt_setbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO1_SWPORTA_DR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), PIN_CS);
		usleep(500*1000);
	}
	else {
		alt_clrbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO1_SWPORTA_DR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), PIN_CS );
		usleep(500*1000);
	}
	
}

void writeSC(int i){
	if (i == 1){
		alt_setbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO2_SWPORTA_DR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), PIN_SC);
		usleep(500*1000);
	}
	else {
		alt_clrbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO2_SWPORTA_DR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), PIN_SC );
		usleep(500*1000);
	}
	
}

void writeSIO(int i){
	if (i == 1){
		alt_setbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO1_SWPORTA_DR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), PIN_SIO);
		usleep(500*1000);
	}
	else {
		alt_clrbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO1_SWPORTA_DR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), PIN_SIO );
		usleep(500*1000);
	}
	
}

void setSIOInput(){
			alt_setbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO1_SWPORTA_DDR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), USER_IO_DIR_GPIO1_Input );
}

void setSIOOutput(){
	alt_setbits_word( ( virtual_base + ( ( uint32_t )( ALT_GPIO1_SWPORTA_DDR_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ), USER_IO_DIR_GPIO1_Output );
}


 readOT(){
	uint32_t  scan_input;
	scan_input = alt_read_word( ( virtual_base + ( ( uint32_t )(  ALT_GPIO2_EXT_PORTA_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ) );		
	if (~scan_input&PIN_OT){
	return 1;
	}
	else return 0;
}

int readSIO(){
	uint32_t  scan_input;
	scan_input = alt_read_word( ( virtual_base + ( ( uint32_t )(  ALT_GPIO2_EXT_PORTA_ADDR ) & ( uint32_t )( HW_REGS_MASK ) ) ) );		
	if (~scan_input&PIN_SIO){
	return 1;
	}
	else return 0;
}


double readTemp(){
		setSIOInput();
		
		double result = 0.0;
		
		unsigned int tempC = 0;
		for(int i = 0; i<16; i++){
			writeSC(1);
			writeSC(0);
			if (readSIO()){
				tempC = tempC | (1 << (15 - i));
			}
		
		}
		
		if (currentResolution == 13) {
			if (tempC >= 4096) {
				result = (4096.0 - (v >> 3)) * 0.0625;
			} else {
				result = (v >> 3) * 0.0625;
			}
		} else if (currentResolution == 14) {
			if (tempC >= 8192) {
				result = (8192.0 - (v >> 2)) * 0.03125;
			} else {
				result = (v >> 2) * 0.03125;
			}            
		} else if (currentResolution == 15) {
			if (tempC >= 16384) {
				result = (16384.0 - (v >> 1)) * 0.015625;
			} else {
				result = (v >> 1) * 0.015625;
			}
		} else {
			if (tempC >= 32768l) {
				result = (32768.0 - v) * 0.0078125;
			} else {
				result = v * 0.0078125;
			}
		}
	
		return result;
}

void writeCMD(int rw, byte reg, byte cmd){
		setSIOOutput();
		
		byte cmdByte = 0;
		char bit;
		cmdByte = cmdByte | rw << 7;
		cmdByte = cmdByte | reg;
		cmdByte = cmdByte | cmd;
		
	
		for(int i = 0; i<8; i++){
			bit = (1 << (7-i)) & cmdByte;
			
			if (bit)
				writeSIO(1);
			else
				writeSIO(0);
			
			writeSC(1);
			writeSC(0);
			
			}
		}
	
}

uint32_t readReg(){
		setSIOInput();
	
		unsigned int tempC = 0;
		for(int i = 0; i<16; i++){
			writeSC(1);
			writeSC(0);
			if (readSIO()){
				tempC = tempC | (1 << (15 - i));
			}
		
		}
		return tempC;
}


uint32_t writeReg(byte msb, byte lsb){
		setSIOOutput();
		
		char bit;
		for(int i = 0; i<8; i++){
			bit = (1 << (7-i)) & msb;
			
			if (bit)
				writeSIO(1);
			else
				writeSIO(0);
			
			writeSC(1);
			writeSC(0);
			
			}
		}
		
		for(int i = 0; i<8; i++){
			bit = (1 << (7-i)) & lsb;
			
			if (bit)
				writeSIO(1);
			else
				writeSIO(0);
			
			writeSC(1);
			writeSC(0);
			
			}
		}
		
		
}
